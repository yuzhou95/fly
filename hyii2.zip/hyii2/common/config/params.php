<?php
return [
    'adminEmail' => 'admin@example.com',
    'supportEmail' => 'support@example.com',
    'user.passwordResetTokenExpire' => 3600,
    'upload_url' => '',
    'default_label_img' => '/statics/images/default.jpg'
];
