<?php
return [
    'Blog'=>'博客',
    'About'=>'关于',
    'Contact'=>'联系',
    'Signup'=>'注册',
    'Login'=>'登录',
    'Email'=>'邮箱',
    'Password'=>'密码',
    'This username has already been taken.'=>'用户名已存在!',
    'This email address has already been taken.'=>'邮箱已存在!',
    'Two times the password is not consitent.'=>'两次输入的密码不一致!',
];