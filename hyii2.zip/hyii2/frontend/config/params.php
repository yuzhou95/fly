<?php
return [
    'adminEmail' => 'admin@example.com',
    'avatar'=>[
        'small'=>'/statics/images/avatar/small.jpg',
    ],
    'default_label_img'=>'',
];
