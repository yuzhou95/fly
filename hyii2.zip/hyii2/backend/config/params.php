<?php
return [
    'adminEmail' => 'admin@example.com',
    'avatar'=>[
        'small'=>'/statics/images/avatar/avatar_small.jpg',
    ]
];
